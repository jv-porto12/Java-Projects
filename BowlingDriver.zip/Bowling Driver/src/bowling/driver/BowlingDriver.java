package bowling.driver;

import java.util.Scanner;

public class BowlingDriver {
    
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner (System.in);
        
        // just some general titles
        System.out.print("Welcome to the Bowling Score Printer! \n");       
        System.out.println("Enter the state of all 5 pins below. \n");
        
        // prompts user for the state of pin 1
        System.out.print("Pin 1: ");
        boolean pin1 = scanner.next().equalsIgnoreCase("up");
        
        // same thing but for pin 2
        System.out.print("Pin 2: ");
        boolean pin2 = scanner.next().equalsIgnoreCase("up");
        
        //pin 3, pin 4, etc. 
        System.out.print("Pin 3: ");
        boolean pin3 = scanner.next().equalsIgnoreCase("up");
        System.out.print("Pin 4: ");
        boolean pin4 = scanner.next().equalsIgnoreCase("up");
        System.out.print("Pin 5: ");
        boolean pin5 = scanner.next().equalsIgnoreCase("up");
        
        // creates the bowling lane using the 'pin' boolean variables
        BowlingLane bowlingLane = new BowlingLane (pin1, pin2, pin3, pin4, pin5);
        
        // executes the constructor for display lane, and the classify lane method
        bowlingLane.displayLane();
        bowlingLane.classifyLane();
    }
}
