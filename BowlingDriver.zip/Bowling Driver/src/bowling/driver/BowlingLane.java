package bowling.driver;

public class BowlingLane {
       
    // make a boolean variable for each pin
    private boolean pin1, pin2, pin3, pin4, pin5;

    // create the BowlingLane constructor
    public BowlingLane(boolean pin1, boolean pin2, boolean pin3, boolean pin4, boolean pin5) 
    {
        this.pin1 = pin1;
        this.pin2 = pin2;
        this.pin3 = pin3;
        this.pin4 = pin4;
        this.pin5 = pin5;
    }

    // create a display lane method
    public void displayLane() 
    {
        System.out.println("\t\t\t\tBowling Lane Configuration: \n\n");
        System.out.print("\tPin 1: " + (pin1 ? "Up" : "Down"));
        System.out.println("\t\t\t\t\t\t\tPin 5: " + (pin5 ? "Up" : "Down"));
        System.out.print("\t\t\tPin 2: " + (pin2 ? "Up" : "Down"));
        System.out.println("\t\t\tPin 4: " + (pin4 ? "Up" : "Down"));
        System.out.println("\t\t\t\t\tPin 3: " + (pin3 ? "Up" : "Down"));
    }

    // create the score system method
    public void classifyLane() 
    {
        // if all pins are 'false' (down) print out strike
        if (!pin1 && !pin2 && !pin3 && !pin4 && !pin5) 
        {
            System.out.println("\n\n\t\t\t\tClassification: X - Strike\n\n\n");
        } 
        // if only the middle 3 pins are down, print aces
        else if (pin1 && !pin2 && !pin3 && !pin4 && pin5) 
        {
            System.out.println("\n\n\t\t\t\tClassification: A - Aces\n\n\n");
        } 
        // if pins 2 and 3 are down, print headsplit
        else if (pin1 && !pin2 && !pin3 && pin4 && pin5) 
        {
            System.out.println("\n\n\t\t\t\tClassification: HS - Headsplit\n\n\n");
        }
        // if pins 3 and 4 are down, print headsplit
        else if (pin1 && pin2 && !pin3 && !pin4 && pin5)
        {
            System.out.println("\n\n\t\t\t\tClasification: HS - Headsplit\n\n\n");
        }
        // otherwise, print out the score. 
        else 
        {
            int score = 0;
            if (!pin1) score += 2;
            if (!pin5) score += 2;
            if (!pin2) score += 3;
            if (!pin4) score += 3;
            if (!pin3) score += 5;
            System.out.println("\n\n\t\t\tClassification: Total score of knocked down pins: " + score + "\n\n\n");
        }
    }
}
