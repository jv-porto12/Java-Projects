package randomquotes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class RandomQuotes {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
        //Makes a string array with 35 quotes
        String quotes[] = new String[35];
        
        //
        String myLine;
        
        
        System.out.println("Welcome to Motivational Quote of the Day!");
        
        while (true)
        {
            int  random = (int)(Math.random() * 35) + 1;
            try
            {
                BufferedReader readFile = new BufferedReader(new FileReader("RandomQuotes.txt"));
            
                for (int i = 0; i < 35; i++)
                {
                    quotes[i] = readFile.readLine();
                }
            
                readFile.close();
            }
            catch (IOException ioe)
            {
                System.err.println("Error opening file.");
                System.err.println(ioe);
            }
        
            System.out.println("\n" + quotes[random] + "\n");
            
            System.out.print("Would you like another quote? (yes/no): ");
            String choice = scanner.nextLine();
            
            if (!choice.equalsIgnoreCase("yes"))
            {
                break;
            }
        }
    }
}
