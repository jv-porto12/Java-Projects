package bookingprogram;

import java.util.Scanner;

public class BookingProgram {
    
    //Checks for valid cart number
    private static boolean isValidCart(int cart)
    {
        if (cart > 6 || cart < 1)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    
    //Checks for valid period number
    private static boolean isValidPeriod(int period)
    {
        if (period > 4 || period < 1)
        {
            return false;
        }
        else            
        {
            return true;
        }
    }
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner (System.in);
        
        //initialize all variables & 2D array
        int cart;
        int period;
        String booking[][] = new String[6][4]; 
        
        //loops through the whole program so that the user can enter multiple teachers
        while (true) 
        {
            //prints all cart options and asks for users choice
            System.out.println("1 - Cart 1");
            System.out.println("2 - Cart 2");
            System.out.println("3 - Cart 3");
            System.out.println("4 - Cart 4");
            System.out.println("5 - Cart 5");
            System.out.println("6 - Cart 6");
            System.out.print("Please select what cart you wish to book out: ");
            cart = scanner.nextInt();
        
            //keeps asking for cart choice if invalid
            while(!isValidCart(cart))
            {
                System.out.println("Invalid cart number");
                System.out.print("Please select what cart you wish to book out: ");
                cart = scanner.nextInt();
            }
            
            //prints out all period options and asks for user choice
            System.out.println("1 - Period 1");
            System.out.println("2 - Period 2");
            System.out.println("3 - Period 3");
            System.out.println("4 - Period 4");
            System.out.print("What period would you like to book for: ");
            period = scanner.nextInt();
        
            //keeps asking for period if choice is invalid
            while (!isValidPeriod(period))
            {
                System.out.println("Invalid period. Try Again");
                System.out.print("What period would you like to book for: ");
                period = scanner.nextInt();
            }
        
            //asks for teachers name
            System.out.print("Please enter the teacher name: ");
            scanner.nextLine();
            String teacherName = scanner.nextLine();
        
            //gets location of the booked out cart
            booking[cart-1][period-1] = teacherName;
            
            //prints the title
            System.out.print("\t\tPeriod 1\tPeriod 2\tPeriod 3\tPeriod 4\n");
            
            //prints out the cart with collected information
            for (int i = 0; i < 6; i++)
            {
                //creates the cart title along the vertical axis
                System.out.print("Cart " + (i+1) + "\t\t");
                for (int j = 0; j < 4; j++)
                {
                    //prints the teachers name in user-entered spot
                    if (booking[i][j] != null)
                    {
                        System.out.print("[" + booking[i][j] + "]\t\t");
                    }
                    //otherwise, keeps the spot empty
                    else
                    {
                        System.out.print("[empty]\t\t");
                    }
                }
                //indents the chart
                System.out.print("\n");
            }
        
            //asks user if they want to add another teacher
            System.out.print("Would you like to make anothoer booking? yes/no. ");
            String choice = scanner.nextLine();
            
            //if the answer is not yes, exit the loop and end the program
            if (!choice.equalsIgnoreCase("yes"))
            {
                break;
            }
        }
    }
}
