package fibonacci;

import java.util.Scanner;

public class Fibonacci {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner (System.in);
        
        // asks the user what term of the sequence they would like and stores answer in the int value 'term'
        System.out.println("The first 8 terms of the fibonacci sequence are 0, 1, 1, 2, 3, 5, 8, 13");
        System.out.print("What term of the fibonacci sequence would you like to know? ");
        int term = scanner.nextInt();
        
        // if term is not a positve integer, keep prompting until it is
        while (term <= 0)
        {
            System.out.println("Term number must be a positve integer");
            System.out.print("What term of the fibonacci sequence would you like to know? ");
            term = scanner.nextInt();
        }
        
        // print out the answer for the proper term
        System.out.println("Fibonacci term " + term + " = " +fibonacci(term));
    }
    
    public static int fibonacci(int t)
    {
        // declares 2 variables, the first 2 numbers of the fibonacci sequence
        int firstNum = 0;
        int secondNum = 1;

        // if user asks for the first term, return 0
        if (t == 1)
        {
            return 0;
        }
        
        // otherwise, calculates and returns the answer using this for loop
        else
        {    
            for (int i = 0; i < (t - 2); i++)
            {
                int temp = secondNum;
                secondNum = firstNum + secondNum;
                firstNum = temp;
            }    
            return secondNum;
        }
    }
}