package wordpyramid;

import java.util.InputMismatchException;
import java.util.Scanner;

public class WordPyramid {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner (System.in);
        
        boolean validWord = false;
        String word;
        
        // keeps going through this loop if word isn't valid
        while (!validWord)
        {
            // asks user to enter a word
            System.out.print("Enter a word: ");
            
            try
            {
                // gets the user input and checks if it has any special characters
                word = scanner.nextLine();
                if (word.matches("[a-zA-Z]+"))
                {
                    // if it doesn't have any special char's (valid) exit the loop
                    // as well, if input is valid print out the original word + the cut versions to make a pyramid
                    validWord = true;
                    System.out.println(word);
                    printWord(word);       
                }
                // otherwise, input isn't valid, prompts user to enter another word
                else
                {
                    System.out.println("Invalid word, please try again.");
                }
            }
            catch (InputMismatchException e)
            {
                System.out.print("Enter a word: ");
            }
        }
    }
    
    private static void printWord(String word)
    {
        // once the word is 2 or less characters, stop cutting it
        if (word.length() <= 2)
        {
            return;
        }
        
        // using the substring method we cut off the first and last char
        String cutWord = word.substring(1, word.length() - 1);
        System.out.println(cutWord);
        printWord(cutWord);
    }
}
