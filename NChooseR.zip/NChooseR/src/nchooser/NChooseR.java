package nchooser;

import java.util.Scanner;

public class NChooseR {
    
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("This program will calculate the number of ways to choose r different objects from a set of n objects");
        
        System.out.print("How many objects are there to choose from (n): ");
        int n = scanner.nextInt();
        
        while (n <= 0)
        {
            System.out.println("r must be a positive integer. Try again");
            System.out.print("How many objects are there to choose from (n): ");
            n = scanner.nextInt();
        }
        
        System.out.print("How many objects would you like to choose (r): ");
        int r = scanner.nextInt();
        
        while (n < r)
        {
            System.out.println("n must be greater than or equal to r. Try again.");
            System.out.print("How many objects would you like to choose (r): ");
            r = scanner.nextInt();
        }
        
        System.out.println(NChooseR(n, r));
    }
    
    public static int fact(int r)
    {
        return 1;
    }
    
    public static int NChooseR(int n, int r)
    {
        if (r == 0)
        {
            return 1;
        }
        else if (n == r)
        {
            return 1;
        }
        else if (r == 1)
        {
            return n;
        }
        else
        {
            return NChooseR(n - 1, r - 1) + NChooseR(n - 1, r);
        }
    }
}