package nameseparator;

import java.util.Scanner;

public class NameSeparator {

    public static void main(String[] args) {
       
        Scanner input = new Scanner(System.in);
        
        String full_name;
        
        System.out.print("Enter your full name: ");
        full_name = input.nextLine();
        
        String[] names = full_name.split(" ");
        
        if (names.length == 3)
        {
            String first_name = names[0].toUpperCase();
            String middle_name = names[1].toUpperCase();
            String last_name = names[2].toUpperCase();
            
            System.out.println(first_name);
            System.out.println(middle_name);
            System.out.println(last_name);
        }
    }
}