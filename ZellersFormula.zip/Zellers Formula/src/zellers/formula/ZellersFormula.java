package zellers.formula;

import static java.lang.StrictMath.floor;
import java.util.Scanner;
//import java.util.InputMismatchException;

public class ZellersFormula {

    //Checks if year is a valid year
    private static boolean isValidYear(int year)
    {
        if (year < 1 || year > 2100)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    //checks if year is a leap year
    private static boolean isLeapYear(int year)
    {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }
    //checks if month is a valid month
    private static boolean isValidMonth(int month)
    {
        if (month < 1 || month > 12)
        {
            return false;
        }
        else
        {
            return true;
        }
    }    
    //checks if day is a valid day
    private static boolean isValidDay(int q, int month,  int year)
    {
        if (q < 1 || q > 31)
        {
            return false;
        }
        if (month == 2 && isLeapYear(year))
        {
            return q <= 29;
        }
        if (month == 2)
        {
            return q <= 28;
        }
        if (month == 4 || month == 6 || month == 9 || month == 11)
        {
            return q <= 30;
        }
        return true;
    }   
    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);
        
        int q, month, year; 
        
        //gets the user to input a year
        System.out.print("Pick a year: ");
        year = input.nextInt();
        
            while (!isValidYear(year))
            
            {
                System.out.println("Invalid year. Try again");
                System.out.print("Pick a year: ");
                year = input.nextInt();
            
            }
       
        //gets the user to input a month in numerical form
        System.out.print("Pick a month numerically: ");
        month = input.nextInt();
        
            while (!isValidMonth(month))
            {
                System.out.println("Invalid month. Try again");
                System.out.print("Pick a month numerically: ");
                month = input.nextInt();
            }
        //gets user to pick a day of the month
        System.out.print("Pick a day of the month: ");
        q = input.nextInt();
        
            while (!isValidDay(q, month, year))
            {
                System.out.println("Invalid day. Try again");
                System.out.print("Enter a day of the month: ");
                q = input.nextInt();
            }
        
        //if month is January or February; uses this calculation and outputs a day of the week
        if (month == 1 || month == 2)
        {
            double y = (year - 1);
            double m = (month + 12);
            double k = (y % 100);
            double j = Math.floor(y / 100);
            double h = (q + floor(13*(m+1)/5) + k + floor(k/4) + floor(j/4) + (5*j)) % 7;                       
            
            if (h == 0)
            {
                System.out.println(month + "/" + q + "/" + year + " is a Saturday");
            }
            else if (h == 1)
            {
                System.out.println(month + "/" + q + "/" + year + " is a Sunday");
            }
            else if (h == 2)
            {
                System.out.println(month + "/" + q + "/" + year + " is a Monday");
            }
            else if (h == 3)
            {
                System.out.println(month + "/" + q + "/" + year + " is a Tuesday");
            }
            else if (h == 4)
            {
                System.out.println(month + "/" + q + "/" + year + " is a Wednesday");
            }
            else if (h == 5)
            {
                System.out.println(month + "/" + q + "/" + year + " is a Thursday");
            }
            else
            {
                System.out.println(month + "/" + q + "/" + year + " is a Friday");
            }
        }
        
        //if month is not January or February; uses this calculation instead, and prints a day of the week
        else
        {
            double k = (year % 100);
            double j = Math.floor(year / 100);
            double h = (q + floor(13*(month+1)/5) + k + floor(k/4) + floor(j/4) + (5*j)) % 7;          
            if (h == 0)
                {
                    System.out.println(month + "/" + q + "/" + year + " is a Saturday");
                }
                else if (h == 1)
                {
                    System.out.println(month + "/" + q + "/" + year + " is a Sunday");
                }
                else if (h == 2)
                {
                    System.out.println(month + "/" + q + "/" + year + " is a Monday");
                }
                else if (h == 3)
                {
                    System.out.println(month + "/" + q + "/" + year + " is a Tuesday");
                }
                else if (h == 4)
                {
                    System.out.println(month + "/" + q + "/" + year + " is a Wednesday");
                }
                else if (h == 5)
                {
                    System.out.println(month + "/" + q + "/" + year + " is a Thursday");
                }
                else
                {
                    System.out.println(month + "/" + q + "/" + year + " is a Friday");
                }
        }
    }
}
