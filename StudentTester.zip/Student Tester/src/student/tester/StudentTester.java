package student.tester;

import java.util.Scanner;

public class StudentTester {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner (System.in);
        
        //asks user for student 1s first name
        System.out.print("First Name: ");
        String firstName1 = scanner.nextLine();
        
        //student 1s last name
        System.out.print("Last Name: ");
        String lastName1 = scanner.nextLine();
        
        //student 1s address
        System.out.print("Address: ");
        String address1 = scanner.nextLine();
        
        // student 1s phone #
        System.out.print("Phone Number: ");
        String phoneNum1 = scanner.nextLine();
        
        // student 1s average grade
        System.out.print("Average Grade: ");
        int grade1 = scanner.nextInt();
        
        //keeps asking unless the grade is between 1 and 100 (%)
        while (grade1 < 1 || grade1 > 100)
        {
            System.out.println("Invalid Grade. Try Again");
            System.out.print("Average Grade: ");
            grade1 = scanner.nextInt();
        }
        
        //asks user for student 1s age.
        System.out.print("Age: ");
        int age1 = scanner.nextInt();
        
        //**Assume we're only dealing with high schoolers**
        while (age1 < 13 || age1 > 18)
        {
            System.out.println("Invalid Age. Try Again");
            System.out.print("Age: ");
            age1 = scanner.nextInt();
        }
        
        scanner.nextLine();
        
        //lets the user know that we only need a first and last name for student 2
        System.out.println("\nAssume we only know student 2s first and last name \n");
        
        System.out.print("First Name: ");
        String firstName2 = scanner.nextLine();
        
        System.out.print("Last Name: ");
        String lastName2 = scanner.nextLine();
        
        System.out.println("\nAssume we only know student 3s average grade and age \n");
        
        System.out.print("Average Grade: ");
        int grade3 = scanner.nextInt();
        
        while (grade3 < 1 || grade3 > 100)
        {
            System.out.println("Invalid Grade. Try Again");
            System.out.print("Average Grade: ");
            grade3 = scanner.nextInt();
        }
        
        System.out.print("Age: ");
        int age3 = scanner.nextInt();
        
        while (age3 < 13 || age3 > 18)
        {
            System.out.println("Invalid Age. Try Again");
            System.out.print("Age: ");
            age3 = scanner.nextInt();
        }
        
        System.out.println("\nAssume we only know nothing about student 4 \n");
        
        Student student1 = new Student (firstName1, lastName1, address1, phoneNum1, grade1, age1);
        Student student2 = new Student(firstName2, lastName2);
        Student student3 = new Student(grade3, age3);
        Student student4 = new Student();
        
        System.out.println("\n");
        System.out.println(student1.toString());
        System.out.println("-------------------------------");
        System.out.println(student2.toString());
        System.out.println("-------------------------------");
        System.out.println(student3.toString());
        System.out.println("-------------------------------");
        System.out.println(student4.toString());
        System.out.println("-------------------------------");
    }
    
}
