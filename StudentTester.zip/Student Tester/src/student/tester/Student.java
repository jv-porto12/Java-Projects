package student.tester;

public class Student {
    
    private String firstName, lastName, address, phoneNum;
    private int ovrGrade, age;
    
    public Student()
    {
        firstName = "John";
        lastName = "Doe";
        address = "Unknown";
        phoneNum = "Unknown";
        ovrGrade = 0;
        age = 0;
    }
    
    public Student(String first_name, String last_name, String add, String phone, int grade, int Age)
    {
        firstName = first_name;
        lastName = last_name;
        address = add;
        phoneNum = phone;
        ovrGrade = grade;
        age = Age;
    }
    
    public Student (int  grade, int Age)
    {
        firstName = "John";
        lastName = "Doe";
        address = "Unknown";
        phoneNum = "Unknown";
        ovrGrade = grade;
        age = Age;
    }
    
    public Student (String first_name, String last_name)
    {
        firstName = first_name;
        lastName = last_name;
        address = "Unknown";
        phoneNum = "Unknown";
        ovrGrade = 0;
        age = 0;
    }
    
    public String toString()
    {
        String output = "First Name: " + firstName + "\n";
        output += "Last  Name: " + lastName + "\n";
        output += "Address: " + address + "\n";
        output += "Phone Number: " + phoneNum + "\n";
        output+= "Average Grade: " + ovrGrade + "\n";
        output += "Age: " + age;
        return output;
    }
}
