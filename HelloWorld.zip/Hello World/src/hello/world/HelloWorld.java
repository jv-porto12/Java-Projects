
package hello.world;

public class HelloWorld {
    
    public static void main(String[] args) {
        System.out.print("Hello World");
    }
    
}
