package lottery;

import java.util.Scanner;

public class Lottery {

    //checks if the user entered more than 1 grand prize
    private static boolean isValidGrand (int GrandPrizeCount)
    {
        if (GrandPrizeCount > 1)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    
    //checks if the user entered more than 2 secondary prizes
    private static boolean isValidSecondary (int SecondaryPrizeCount)
    {
        if (SecondaryPrizeCount > 2)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    
    //checks if more than 7 early birds were entered
    private static boolean isValidEarly (int EarlyBirdCount)
    {
        if (EarlyBirdCount > 7)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        String[] TypeWinner = new String[11];
        String[] names = new String[11];
        int EarlyBirdCount = 0;
        int GrandPrizeCount = 0;
        int SecondaryPrizeCount = 0;
        
        //prints a title
        System.out.println("Welcome to the Lottery Organizer!");
        System.out.println("");
        
        //loop that asks the name of the winner and the prize they won 10 times
        for (int i = -1; i < 9; i++)
        {
            //asks for the name
            System.out.print("Name of winner: ");
            names[i+1] = scanner.nextLine();
            
            //asks what prize was won by the name entered above
            System.out.print("What prize did " + names[i+1] + " win: ");
            TypeWinner[i+1] = scanner.nextLine();

                //increases variable count for corresponding prize
                if (TypeWinner[i+1].equalsIgnoreCase("Grand Prize") || TypeWinner[i+1].equalsIgnoreCase("Grand"))
                {
                    GrandPrizeCount++;
                }
                else if (TypeWinner[i+1].equalsIgnoreCase("Secondary Prize") || TypeWinner[i+1].equalsIgnoreCase("Secondary"))
                {
                    SecondaryPrizeCount++;
                }
                else if (TypeWinner[i+1].equalsIgnoreCase("Early Bird") || TypeWinner[i+1].equalsIgnoreCase("Early"))
                {
                    EarlyBirdCount++;
                }
                
                //keeps asking for the prize if there are too many early birds
                while (!isValidEarly(EarlyBirdCount))
                {
                    EarlyBirdCount -= 1;
                    System.out.println("Maximum of 7 early bird winners is allowed. Try Again");
                    System.out.print("What prize did " + names[i+1] + " win: ");
                    TypeWinner[i+1] = scanner.nextLine();
                    
                    //again, increases corresponding variable
                    if (TypeWinner[i+1].equalsIgnoreCase("Early Bird") || TypeWinner[i+1].equalsIgnoreCase("Early"))
                    {
                        EarlyBirdCount++;
                    }
                    else if (TypeWinner[i+1].equalsIgnoreCase("Grand Prize") || TypeWinner[i+1].equalsIgnoreCase("Grand"))
                    {
                        GrandPrizeCount++;
                    }
                    else if (TypeWinner[i+1].equalsIgnoreCase("Secondary Prize") || TypeWinner[i+1].equalsIgnoreCase("Secondary"))
                    {
                        SecondaryPrizeCount++;
                    }
                }
                
                //keeps asking for prize is too many grand prizes are entered
                while (!isValidGrand(GrandPrizeCount))
                {
                    GrandPrizeCount -= 1;
                    System.out.println("Maximum of 1 grand prize winner is allowed. Try Again");
                    System.out.print("What prize did " + names[i+1] + " win: ");
                    TypeWinner[i+1] = scanner.nextLine();
                    
                    if (TypeWinner[i+1].equalsIgnoreCase("Grand Prize") || TypeWinner[i+1].equalsIgnoreCase("Grand"))
                    {
                        GrandPrizeCount++;
                    }
                    else if (TypeWinner[i+1].equalsIgnoreCase("Secondary Prize") || TypeWinner[i+1].equalsIgnoreCase("Secondary"))
                    {
                        SecondaryPrizeCount++;
                    }
                    else if (TypeWinner[i+1].equalsIgnoreCase("Early Bird") || TypeWinner[i+1].equalsIgnoreCase("Early"))
                    {
                        EarlyBirdCount++;
                    }
                }
                
                //keeps asking if too many secondary prizes are entered
                while (!isValidSecondary(SecondaryPrizeCount))
                {
                    SecondaryPrizeCount -= 1;
                    System.out.println("Maximum of 2 secondary prize winners are allowed. Try Again");
                    System.out.print("What prize did " + names[i+1] + " win: ");
                    TypeWinner[i+1] = scanner.nextLine();
                    
                    if (TypeWinner[i+1].equalsIgnoreCase("Secondary Prize") || TypeWinner[i+1].equalsIgnoreCase("Secondary"))
                    {
                        SecondaryPrizeCount++;
                    }
                    else if (TypeWinner[i+1].equalsIgnoreCase("Grand Prize") || TypeWinner[i+1].equalsIgnoreCase("Grand"))
                    {
                        GrandPrizeCount++;
                    }
                    else if (TypeWinner[i+1].equalsIgnoreCase("Early Bird") || TypeWinner[i+1].equalsIgnoreCase("Early"))
                    {
                        EarlyBirdCount++;
                    }
                }
        }


        //searches through the array for the grand prize winner and prints it out
        for (int j = 0; j < 10; j++)
        {
            if (TypeWinner[j].equalsIgnoreCase("Grand Prize") || TypeWinner[j].equalsIgnoreCase("Grand"))
            {
                System.out.println(names[j] + " - Grand Prize");
                break;
            }
        }
        
        //searches for both secondary winners and prints them out
        for (int p = 0; p < 10; p++)
        {
            if (TypeWinner[p].equalsIgnoreCase("Secondary Prize") || TypeWinner[p].equalsIgnoreCase("Secondary"))
            {
                System.out.println(names[p] + " - Secondary Prize");
            }
        }
        
        //searches for early bird winners and prints them out
        for (int t = 0; t < 10; t++)
        {
            if (TypeWinner[t].equalsIgnoreCase("Early Bird") || TypeWinner[t].equalsIgnoreCase("Early"))
            {
                System.out.println(names[t] + " - Early Bird");
            }
        }
    }
}
