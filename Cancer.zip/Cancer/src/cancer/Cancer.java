package cancer;

public class Cancer {
  // make global variable grid
public static String grid[][];
    
    public static void main(String[] args) {
    
        int row, col;
        int blobCount = 0;
    
        //Create 2D array size 15 x 15
        grid = new String[15][15];

        //Fill the array with plus signs
        for (row = 0; row < 15; row++) 
        {
            for (col = 0; col < 15; col++) 
            {
                grid[row][col] = "+";
            }
        }

        //Fill 70 random elements in the array with a minus signs (cancer cells)
        //Do not choose an element along the border
        for (int i = 0; i < 70; i++) 
        {
            row = (int) (Math.random() * 10 + 1);
            col = (int) (Math.random() * 10 + 1);
            grid[row][col] = "-";
        }

        //Print out the current grid
        displayGrid();

        int blobRow;
        int blobCol;
    
        // enters nested for loop to check each character in the grid
        for (int i = 0; i < 15; i++)
        {
            blobRow = i;
        
            for (int j = 0; j < 15; j++)
            {
                blobCol = j;
            
                // if there is a cancer cell, increase blob count by 1
                if (grid[i][j].equalsIgnoreCase("-"))
                {
                    blobCount++;
                }
                floodFill(blobRow, blobCol);
            }    
        }
    
        // prints out how many blobs there were
        System.out.println("The file had " + blobCount + " cancer spot(s) in it");
        System.out.println("The new grid is:");
        
        //Print out the new grid
        displayGrid();
  }
    
    public static void floodFill(int row, int col) {
    if (grid[row][col].equals("-")) 
    {
        grid[row][col] = " ";
        floodFill(row - 1, col - 1);
        floodFill(row - 1, col);
        floodFill(row - 1, col + 1);
        floodFill(row, col - 1);
        floodFill(row, col + 1);
        floodFill(row + 1, col - 1);
        floodFill(row + 1, col);
        floodFill(row + 1, col + 1);
    }
}

  public static void displayGrid() {
    String output = "+";
    for (int row = 0; row <= 14; row++) 
    {
        for (int col = 0; col <= 14; col++) 
        {
            output += grid[row][col];
        }
        output += "\n";
    }
    System.out.println(output);
    }
}
